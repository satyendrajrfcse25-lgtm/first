Dibyasree Birthday Site

Files:
- index.html  (complete ready-made birthday website)

How to use quickly:
1. Open index.html in any browser to view locally.
2. To get a public link fast: go to vercel.com/new or netlify.com/drop
3. Drag and drop this folder or just the index.html file.
4. You will get a shareable public link in under a minute.
